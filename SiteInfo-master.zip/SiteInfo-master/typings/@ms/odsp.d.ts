// Type definitions for Microsoft ODSP projects
// Project: ODSP

/* Global definition for UNIT_TEST builds */
declare const UNIT_TEST: boolean;