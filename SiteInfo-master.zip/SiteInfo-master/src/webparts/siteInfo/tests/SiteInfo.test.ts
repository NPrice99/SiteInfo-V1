/// <reference types="mocha" />

import { assert } from 'chai';

describe('SiteInfoWebPart', () => {
  it('should do something', () => {
    assert.ok(true);
  });
});
