export interface ISiteInfoWebPartProps {
  description: string;
  showLists: boolean;
  showUser: boolean;
  self: any;
}
